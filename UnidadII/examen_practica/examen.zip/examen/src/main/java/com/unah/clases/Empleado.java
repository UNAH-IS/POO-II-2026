package com.unah.clases;

import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Empleado extends Persona {
    private int edad;
    private double salarioBase;
    private LocalDate fechaIngreso;
    private Departamento departamento;
    private Supervisor supervisor;
    private ArrayList<String> habilidades;
    private ArrayList<Beneficio> beneficios;

    public Empleado() {
        this.habilidades = new ArrayList<>();
        this.beneficios = new ArrayList<>();
    }

    public Empleado(String nombres, String apellidos, String identidad, int edad, double salarioBase,
                    LocalDate fechaIngreso, Departamento departamento, Supervisor supervisor,
                    ArrayList<String> habilidades, ArrayList<Beneficio> beneficios) {
        super(nombres, apellidos, identidad);
        this.edad = edad;
        this.salarioBase = salarioBase;
        this.fechaIngreso = fechaIngreso;
        this.departamento = departamento;
        this.supervisor = supervisor;
        this.habilidades = habilidades;
        this.beneficios = beneficios;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    public ArrayList<String> getHabilidades() {
        return habilidades;
    }

    public void setHabilidades(ArrayList<String> habilidades) {
        this.habilidades = habilidades;
    }

    public ArrayList<Beneficio> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(ArrayList<Beneficio> beneficios) {
        this.beneficios = beneficios;
    }
}
