package com.unah.clases;

import java.time.LocalDate;
import java.util.ArrayList;

public class EmpleadoAdministrativo extends Empleado {
    private String cargoAdministrativo;
    private String nivelAcceso;

    public EmpleadoAdministrativo() {
    }

    public EmpleadoAdministrativo(String nombres, String apellidos, String identidad, int edad, double salarioBase,
                                  LocalDate fechaIngreso, Departamento departamento, Supervisor supervisor,
                                  ArrayList<String> habilidades, ArrayList<Beneficio> beneficios,
                                  String cargoAdministrativo, String nivelAcceso) {
        super(nombres, apellidos, identidad, edad, salarioBase, fechaIngreso, departamento, supervisor, habilidades, beneficios);
        this.cargoAdministrativo = cargoAdministrativo;
        this.nivelAcceso = nivelAcceso;
    }

    public String getCargoAdministrativo() {
        return cargoAdministrativo;
    }

    public void setCargoAdministrativo(String cargoAdministrativo) {
        this.cargoAdministrativo = cargoAdministrativo;
    }

    public String getNivelAcceso() {
        return nivelAcceso;
    }

    public void setNivelAcceso(String nivelAcceso) {
        this.nivelAcceso = nivelAcceso;
    }
}
