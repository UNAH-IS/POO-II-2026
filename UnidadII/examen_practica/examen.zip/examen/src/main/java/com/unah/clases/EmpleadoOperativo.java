package com.unah.clases;

import java.time.LocalDate;
import java.util.ArrayList;

public class EmpleadoOperativo extends Empleado {
    private String areaTrabajo;
    private String turnoAsignado;

    public EmpleadoOperativo() {
    }

    public EmpleadoOperativo(String nombres, String apellidos, String identidad, int edad, double salarioBase,
                             LocalDate fechaIngreso, Departamento departamento, Supervisor supervisor,
                             ArrayList<String> habilidades, ArrayList<Beneficio> beneficios,
                             String areaTrabajo, String turnoAsignado) {
        super(nombres, apellidos, identidad, edad, salarioBase, fechaIngreso, departamento, supervisor, habilidades, beneficios);
        this.areaTrabajo = areaTrabajo;
        this.turnoAsignado = turnoAsignado;
    }

    public String getAreaTrabajo() {
        return areaTrabajo;
    }

    public void setAreaTrabajo(String areaTrabajo) {
        this.areaTrabajo = areaTrabajo;
    }

    public String getTurnoAsignado() {
        return turnoAsignado;
    }

    public void setTurnoAsignado(String turnoAsignado) {
        this.turnoAsignado = turnoAsignado;
    }
}
