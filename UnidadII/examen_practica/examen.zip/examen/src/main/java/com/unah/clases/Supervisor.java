package com.unah.clases;

public class Supervisor extends Persona {
    private int aniosExperiencia;
    private String extensionTelefonica;

    public Supervisor() {
    }

    public Supervisor(String nombres, String apellidos, String identidad, int aniosExperiencia, String extensionTelefonica) {
        super(nombres, apellidos, identidad);
        this.aniosExperiencia = aniosExperiencia;
        this.extensionTelefonica = extensionTelefonica;
    }

    public int getAniosExperiencia() {
        return aniosExperiencia;
    }

    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }

    public String getExtensionTelefonica() {
        return extensionTelefonica;
    }

    public void setExtensionTelefonica(String extensionTelefonica) {
        this.extensionTelefonica = extensionTelefonica;
    }
}
