package com.unah.clases;

public abstract class Persona {
    private String nombres;
    private String apellidos;
    private String identidad;

    public Persona() {
    }

    public Persona(String nombres, String apellidos, String identidad) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.identidad = identidad;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getIdentidad() {
        return identidad;
    }

    public void setIdentidad(String identidad) {
        this.identidad = identidad;
    }
}
